// The independent layout validator: reads a finished layout (its pieces as drawn, in plan feet) and the brief it was
// made from, and measures each check itself. It never reads the generator's scores, its plan checks
// (lib/siteplan.mjs check) or its metrics; the only thing it shares with the engine is the decoder that turns a piece's
// stored shape into an outline (S.shapeOf) and the drawn stall marks (S.stallCentres), which are the geometry the user
// sees. Each check returns:
//   { id, title, status: 'pass' | 'fail' | 'unknown' | 'n/a', hard, rule, basis, measured, required, units, tolerance,
//     features: [ids], note }
// basis: 'verified' (a rule with a cited requirement), 'assumption' (a planning default), 'brief' (what was asked),
// 'geometry' (a property of the drawing itself), 'none'. Missing evidence is 'unknown', never 'pass'.
//
// Overall: 'fail' when a hard check fails; 'incomplete' when a hard check is unknown; else 'pass'. A pass says the
// layout meets the brief and the stated rules at concept level; checks that rest on assumptions are listed, and the
// engineering checks this validator does not perform (drainage, turning movements, fire route distance, grading,
// utilities) are reported unknown every time.
import * as S from './siteplan.mjs';
import polyclip from './vendor/polyclip.mjs';
import * as TURN from './turning.mjs';
import { QUEUE_NEED } from './btsite.mjs';

export const VALIDATOR_VERSION = 'rei.validate/1';
export const TOL = { len: 0.5, area: 1, touch: 1.0, lock: 0.01 }; // ft, sq ft, ft (pieces meet), ft (a locked piece unmoved)

const PAVED = ['drive', 'parking', 'truck', 'field'];
const SOLID = ['building', 'garage', 'pool', 'pond', 'court', 'play', 'trash', 'canopy', 'foodtruck'];
const IGNORE = ['lot', 'sign', 'fence', 'keepout', 'green', 'trail', 'plaza', 'patio', 'tanks'];
const FLOOR_H = { multifamily: 10, townhomes: 10, duplex: 10, sfr: 11, retail: 20, restaurant: 18, office: 13, medical: 14, hotel: 11, industrial: 36, storage: 10, amenity: 18, other: 16 };

// ---------- geometry (own implementations; polyclip only for intersection areas) ----------
const area = r => { let s = 0; for (let i = 0, j = r.length - 1; i < r.length; j = i++) s += r[j][0] * r[i][1] - r[i][0] * r[j][1]; return Math.abs(s / 2); };
const perim = r => { let s = 0; for (let i = 0, j = r.length - 1; i < r.length; j = i++) s += Math.hypot(r[i][0] - r[j][0], r[i][1] - r[j][1]); return s; };
const signed = r => { let s = 0; for (let i = 0, j = r.length - 1; i < r.length; j = i++) s += r[j][0] * r[i][1] - r[i][0] * r[j][1]; return s / 2; };
function inPoly(p, r) { let c = false; for (let i = 0, j = r.length - 1; i < r.length; j = i++) { const a = r[i], b = r[j]; if ((a[1] > p[1]) !== (b[1] > p[1]) && p[0] < (b[0] - a[0]) * (p[1] - a[1]) / (b[1] - a[1]) + a[0]) c = !c; } return c; }
function segDist(p, a, b) { const dx = b[0] - a[0], dy = b[1] - a[1], L = dx * dx + dy * dy, t = L ? Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L)) : 0; return Math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy); }
const ptPolyDist = (p, r) => { let d = Infinity; for (let i = 0; i < r.length; i++) d = Math.min(d, segDist(p, r[i], r[(i + 1) % r.length])); return d; };
function segsCross(a, b, c, d) { const o = (p, q, r) => (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0]); const d1 = o(c, d, a), d2 = o(c, d, b), d3 = o(a, b, c), d4 = o(a, b, d); return d1 * d2 < 0 && d3 * d4 < 0; }
function polyDist(A, B) {
  for (let i = 0; i < A.length; i++) for (let j = 0; j < B.length; j++) if (segsCross(A[i], A[(i + 1) % A.length], B[j], B[(j + 1) % B.length])) return 0;
  if (inPoly(A[0], B) || inPoly(B[0], A)) return 0;
  let d = Infinity; for (const p of A) d = Math.min(d, ptPolyDist(p, B)); for (const p of B) d = Math.min(d, ptPolyDist(p, A)); return d;
}
const box = r => { let a = Infinity, b = Infinity, c = -Infinity, d = -Infinity; for (const [x, y] of r) { if (x < a) a = x; if (y < b) b = y; if (x > c) c = x; if (y > d) d = y; } return [a, b, c, d]; };
const boxGap = (A, B) => Math.max(A[0] - B[2], B[0] - A[2], A[1] - B[3], B[1] - A[3], 0);
const ccw = r => signed(r) >= 0 ? r : r.slice().reverse();
const closed = r => { const q = ccw(r); return q.concat([q[0]]); };
function interArea(A, B) { try { return polyclip.intersection([closed(A)], [closed(B)]).reduce((s, pg) => s + area(pg[0].slice(0, -1)) - pg.slice(1).reduce((t, h) => t + area(h.slice(0, -1)), 0), 0); } catch { return NaN; } }
const finite = r => Array.isArray(r) && r.length >= 3 && r.every(p => Number.isFinite(p[0]) && Number.isFinite(p[1]));

// a piece's outline(s): a route (path + width) as one rectangle a segment, so a bent drive is measured as drawn
function shapesOf(e) {
  if (e.path?.length >= 2 && !e.poly && +e.width > 0 && e.kind !== 'trail') {
    const w = +e.width / 2, out = [];
    for (let i = 1; i < e.path.length; i++) { const a = e.path[i - 1], b = e.path[i], L = Math.hypot(b[0] - a[0], b[1] - a[1]); if (L < 0.01) continue; const nx = -(b[1] - a[1]) / L * w, ny = (b[0] - a[0]) / L * w; out.push([[a[0] + nx, a[1] + ny], [a[0] - nx, a[1] - ny], [b[0] - nx, b[1] - ny], [b[0] + nx, b[1] + ny]]); }
    return out;
  }
  try { const s = S.shapeOf(e); return finite(s) ? [s] : []; } catch { return []; }
}
// angled stalls, measured from the stripes as drawn (S.stallLines: the marks the user sees) and the planted marks
// (S.capsOf), not from the engine's count: stripes slanting 20-80 degrees to the row's long side, taken in order along
// each line of them; two neighbouring stripes make a stall when they are parallel, a stall width apart (square to the
// stripes), and the parallelogram between them holds the design car (ANG_CAR) and is not planted. null when the piece
// has no slanted stripes (square stalls are counted from their marks as before). [{ c, corners }]
export const ANG_CAR = { L: 17.3, W: 6.6, w: 9, source: 'ULI/NPA The Dimensions of Parking (5th ed.): design vehicle about 6 ft 7 in × 17 ft 4 in (an 85th-percentile car), in a 9 ft stall' };
export function angledStalls(e, rows = shapesOf(e)) {
  let L; try { L = S.stallLines(e); } catch { return null; } const r0 = rows[0]; if (!L?.length || !r0 || r0.length < 3) return null;
  let ax = null, best = 0; for (let i = 0; i < r0.length; i++) { const a = r0[i], b = r0[(i + 1) % r0.length], l = Math.hypot(b[0] - a[0], b[1] - a[1]); if (l > best) { best = l; ax = [(b[0] - a[0]) / l, (b[1] - a[1]) / l]; } }
  const nx = [-ax[1], ax[0]], dir = l => { const d = [l[1][0] - l[0][0], l[1][1] - l[0][1]], n = Math.hypot(d[0], d[1]) || 1; return [d[0] / n, d[1] / n, n]; };
  const slant = L.map(l => { const [dx, dy, len] = dir(l), c = Math.abs(dx * ax[0] + dy * ax[1]), th = Math.acos(Math.min(1, c)) * 180 / Math.PI; return { l, len, th, u: [dx, dy], m: [(l[0][0] + l[1][0]) / 2, (l[0][1] + l[1][1]) / 2] }; }).filter(q => q.th >= 20 && q.th <= 80);
  if (!slant.length) return null;
  let planted = []; try { planted = S.capsOf(e).map(c => c.poly); } catch { planted = []; }
  const byV = slant.map(q => ({ q, v: q.m[0] * nx[0] + q.m[1] * nx[1] })).sort((p, q) => p.v - q.v), groups = []; // (stripes of one row share their midline)
  for (const x of byV) { const g = groups[groups.length - 1]; if (g && x.v - g.v < 1) g.list.push(x.q); else groups.push({ v: x.v, list: [x.q] }); }
  const out = [];
  for (const { list } of groups) {
    list.sort((p, q) => (p.m[0] * ax[0] + p.m[1] * ax[1]) - (q.m[0] * ax[0] + q.m[1] * ax[1]));
    for (let k = 0; k + 1 < list.length; k++) {
      const a = list[k], b = list[k + 1]; if (Math.abs(a.u[0] * b.u[1] - a.u[1] * b.u[0]) > 0.02) continue; // (parallel)
      const gap = Math.abs((b.l[0][0] - a.l[0][0]) * -a.u[1] + (b.l[0][1] - a.l[0][1]) * a.u[0]), th = a.th * Math.PI / 180; // (square to the stripes)
      if (gap < ANG_CAR.w - 0.05 || Math.min(a.len, b.len) < ANG_CAR.L + ANG_CAR.W / Math.tan(th) - 0.05) continue;
      const corners = [a.l[0], b.l[0], b.l[1], a.l[1]], c = [(a.m[0] + b.m[0]) / 2, (a.m[1] + b.m[1]) / 2];
      if (planted.some(pq => inPoly(c, pq))) continue; out.push({ c, corners });
    }
  }
  return out;
}
const isEntrance = e => e.kind === 'drive' && (e.entry || e.emergency || e.name === 'Main entry' || /^Entrance\b/.test(e.name || '') || e.through); // (an emergency access lane meets the lot line by design)
function levels(e) {
  if (Number.isFinite(+e.z0) || Number.isFinite(+e.z1)) return [+e.z0 || 0, Number.isFinite(+e.z1) ? +e.z1 : (+e.z0 || 0) + 10];
  if (e.kind === 'building') { const z0 = +e.over > 0 ? +e.over : 0, gr = S.groundOf(e); return [z0, z0 + (gr ? gr.floors * S.GROUND_H + ((+e.floors || 1) - gr.floors) * (FLOOR_H[e.use] || 10) : (+e.floors || 1) * (FLOOR_H[e.use] || 10))]; }
  if (e.kind === 'garage') return [0, (+e.levels || 4) * 10];
  if (e.kind === 'canopy') return [14, 18];
  return [0, 1];
}
// a tower on a podium (form 'tower'): its podium levels, how many of them are parking (as the building declares it),
// the tower floors above and the tower's floor plate (its drawn outline)
function towerOf(e) {
  if (e.kind !== 'building' || e.form !== 'tower' || !(+e.podium > 0) || !((+e.floors || 1) > +e.podium)) return null;
  const pk = e.parkLevels == null ? 0 : e.parkLevels === 'auto' ? S.parkLevelsOf(e) : Math.max(0, Math.min(+e.podium, Math.round(+e.parkLevels) || 0));
  return { podium: +e.podium, park: pk, up: (+e.floors || 1) - +e.podium, plate: area(S.towerOutline(e)) };
}
// stalls on a podium's parking levels: counted from its garage plan (lib/siteplan.mjs garagePlan, the plan the sheet
// draws): the ground level less its lobby, then whole levels; the ramp and two cores out of every level
function podiumGrid(e, levels) { if (!(levels > 0)) return 0; const g = S.garagePlan({ ...e, parkLevels: levels }); return S.podiumLevelSum(g, levels, levels === +e.parkLevels ? e.parkLast : null); } // (a last level only partly parking: the spaces it keeps)
const vOverlap = (a, b) => Math.min(a[1], b[1]) - Math.max(a[0], b[0]) > 0.01;

// ---------- edge roles, measured here ----------
function roles(ring, front, streets = []) {
  const n = ring.length, nrm = i => { const a = ring[i], b = ring[(i + 1) % n], L = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1; return [(b[1] - a[1]) / L, -(b[0] - a[0]) / L]; }; // outward for a CCW ring
  const f = nrm(front), st = new Set(streets);
  return ring.map((_, i) => i === front || st.has(i) ? 'front' : (n2 => n2[0] * f[0] + n2[1] * f[1])(nrm(i)) < -0.5 ? 'rear' : 'side');
}

// ---------- the checks ----------
export function validateLayout(layout, brief = null) {
  const C = [], add = c => { C.push({ hard: true, features: [], units: null, tolerance: null, measured: null, required: null, basis: 'geometry', note: '', ...c }); };
  const ring0 = layout.ring || brief?.site?.ring || [], els = (layout.elements || []).filter(e => e && e.kind);
  const R = brief?.rules?.values || {}, ruleOf = k => R[k] || null, basisOf = r => !r ? 'none' : r.cls === 'verified' ? 'verified' : 'assumption';
  const ring = finite(ring0) ? ccw(ring0) : null, flip = ring && ring !== ring0 && signed(ring0) < 0;
  const n = ring0.length, mapEdge = i => flip ? ((n - 2 - i) % n + n) % n : i;
  const front = mapEdge(layout.front ?? brief?.site?.front ?? 0), streets = (layout.streets || brief?.site?.streets || []).map(mapEdge);
  const sh = new Map(els.map(e => [e, shapesOf(e)]));
  const bx = new Map(els.map(e => [e, sh.get(e).length ? box(sh.get(e).flat()) : null]));
  const id = e => e.id || e.name || e.kind;

  // 1. geometry
  {
    const bad = els.filter(e => !IGNORE.includes(e.kind) && (!sh.get(e).length || sh.get(e).some(s => !finite(s) || area(s) < 0.01)));
    add({ id: 'geometry.valid', title: 'Site and pieces are valid shapes', status: !ring ? 'fail' : bad.length ? 'fail' : 'pass', measured: bad.length, required: 0, units: 'invalid pieces', features: bad.map(id), rule: 'Finite coordinates, non-zero area', note: !ring ? 'The site boundary is missing or not finite.' : '' });
    if (ring) { let crosses = false; for (let i = 0; i < n && !crosses; i++) for (let j = i + 2; j < n; j++) { if (i === 0 && j === n - 1) continue; if (segsCross(ring[i], ring[(i + 1) % n], ring[j], ring[(j + 1) % n])) { crosses = true; break; } } if (crosses) C[C.length - 1].status = 'fail', C[C.length - 1].note = 'The site boundary crosses itself.'; }
  }
  if (!ring) return finish(C, layout, brief);
  { const live = els.filter(e => bx.get(e) && sh.get(e).every(finite)); els.length = 0; els.push(...live); } // the invalid ones are reported above; the rest is checked
  const holes = (brief?.site?.holes || []).filter(finite);

  // 2. containment: every built or paved piece inside the site, none in a hole. A drive may run on past a street edge
  // where access is allowed (its apron meets the street in the right-of-way), up to ROW_FT; nowhere else.
  const access0 = new Set((brief?.site?.access?.edges || [front, ...streets]).map(mapEdge));
  const nearestEdge = p => { let best = -1, bd = Infinity; for (let i = 0; i < n; i++) { const d = segDist(p, ring[i], ring[(i + 1) % n]); if (d < bd) { bd = d; best = i; } } return { edge: best, d: bd }; };
  {
    const out = [], ROW_FT = 40;
    for (const e of els) {
      if (IGNORE.includes(e.kind) && e.kind !== 'plaza') continue;
      for (const s of sh.get(e)) {
        const past = s.filter(p => !inPoly(p, ring) && ptPolyDist(p, ring) > TOL.len);
        const okApron = e.kind === 'drive' && past.every(p => { const q = nearestEdge(p); return access0.has(q.edge) && q.d <= ROW_FT; });
        if (past.length && !okApron || holes.some(h => interArea(s, h) > TOL.area)) { out.push(id(e)); break; }
      }
    }
    add({ id: 'site.containment', title: 'Everything inside the property line', status: out.length ? 'fail' : 'pass', measured: out.length, required: 0, units: 'pieces outside', tolerance: TOL.len + ' ft (drives may meet the street across an access edge)', features: out, rule: 'Nothing built or paved past the boundary or in a hole' });
  }

  // 3. setbacks: buildings from each edge by its role; paving from non-street edges by the paving buffer
  {
    const rv = ruleOf('setbacks'), sb = { ...S.SETBACKS, ...(rv?.v || brief?.site?.setbacks || layout.setbacks || {}) }, rl = roles(ring, front, streets);
    let worst = Infinity; const bad = [], badPave = [];
    for (const e of els.filter(x => x.kind === 'building' && !x.future)) for (const s of sh.get(e)) for (let i = 0; i < n; i++) {
      const need = +sb[rl[i]] || 0, a = ring[i], b = ring[(i + 1) % n]; let d = Infinity; for (const p of s) d = Math.min(d, segDist(p, a, b));
      worst = Math.min(worst, d - need); if (d < need - TOL.len) { bad.push(id(e)); break; }
    }
    for (const e of els.filter(x => PAVED.includes(x.kind) && !isEntrance(x))) for (const s of sh.get(e)) for (let i = 0; i < n; i++) {
      if (rl[i] === 'front') continue; const need = +(sb.paving ?? 0) || 0, a = ring[i], b = ring[(i + 1) % n]; let d = Infinity; for (const p of s) d = Math.min(d, segDist(p, a, b)); if (d < need - TOL.len) { badPave.push(id(e)); break; }
    }
    add({ id: 'site.setbacks.buildings', title: 'Building setbacks', status: bad.length ? 'fail' : 'pass', measured: Number.isFinite(worst) ? +worst.toFixed(2) : null, units: 'ft least margin', required: { front: sb.front, side: sb.side, rear: sb.rear }, tolerance: TOL.len + ' ft', features: [...new Set(bad)], basis: basisOf(rv), rule: rv?.source || 'Engine default setbacks (assumption)' });
    add({ id: 'site.setbacks.paving', title: 'Paving buffer from side and rear lines', status: badPave.length ? 'fail' : 'pass', measured: badPave.length, units: 'pieces inside the buffer', required: sb.paving, tolerance: TOL.len + ' ft', features: [...new Set(badPave)], basis: basisOf(rv), rule: rv?.source || 'Engine default paving buffer (assumption)', hard: false });
  }

  // 4. exclusions (easements, floodplain, keep-outs, the brief's and the plan's own)
  {
    const ex = [...(brief?.site?.exclusions || []).map(x => ({ id: x.id, ring: x.ring })), ...els.filter(e => e.kind === 'keepout').map(e => ({ id: id(e), ring: sh.get(e)[0] }))].filter(x => finite(x.ring));
    const hits = [];
    for (const x of ex) { const xb = box(x.ring); for (const e of els) { if (![...PAVED, ...SOLID].includes(e.kind) || isEntrance(e) && e.through) continue; if (!bx.get(e) || boxGap(xb, bx.get(e)) > 0) continue; for (const s of sh.get(e)) { const a = interArea(s, x.ring); if (a > TOL.area) { hits.push(id(e) + ' on ' + x.id + ' (' + Math.round(a) + ' sf)'); break; } } } }
    add({ id: 'site.exclusions', title: 'Nothing built or paved on excluded land', status: !ex.length ? 'n/a' : hits.length ? 'fail' : 'pass', measured: hits.length, units: 'conflicts', tolerance: TOL.area + ' sf', features: hits, rule: 'Exclusions, easements and keep-outs stay clear' });
  }

  // 5. overlaps, level-aware: solids with solids; buildings with paving at the same level
  {
    const list = els.filter(e => SOLID.includes(e.kind) || PAVED.includes(e.kind)), hits = [];
    for (let i = 0; i < list.length; i++) for (let j = i + 1; j < list.length; j++) {
      const a = list[i], b = list[j], pa = PAVED.includes(a.kind), pb = PAVED.includes(b.kind);
      if (pa && pb) continue; // paving meets paving by design
      if ((pa || pb) && !(a.kind === 'building' || b.kind === 'building' || a.kind === 'pond' || b.kind === 'pond' || a.kind === 'pool' || b.kind === 'pool')) continue;
      if (a.kind === 'canopy' || b.kind === 'canopy') continue; // a fuel canopy stands over its paving
      if (!bx.get(a) || !bx.get(b) || boxGap(bx.get(a), bx.get(b)) > 0) continue;
      if (!vOverlap(levels(a), levels(b))) continue; // stacked: a podium under apartments, a building over tuck-under parking
      let A = 0; for (const s of sh.get(a)) for (const t of sh.get(b)) A += interArea(s, t) || 0;
      if (A > TOL.area) hits.push(id(a) + ' × ' + id(b) + ' (' + Math.round(A) + ' sf)');
    }
    add({ id: 'overlap.level-aware', title: 'No two things in the same place at the same level', status: hits.length ? 'fail' : 'pass', measured: hits.length, units: 'overlaps', tolerance: TOL.area + ' sf', features: hits.slice(0, 40), rule: 'Pieces overlap only when their levels differ (stacked uses, parking under a building)' });
  }

  // 6. separation between buildings (at the same level)
  {
    const rv = ruleOf('buildingSeparation'), need = +rv?.v || 0, B = els.filter(e => e.kind === 'building' && !e.future), bad = []; let least = Infinity;
    for (let i = 0; i < B.length; i++) for (let j = i + 1; j < B.length; j++) {
      const a = B[i], b = B[j]; if (!bx.get(a) || !bx.get(b) || boxGap(bx.get(a), bx.get(b)) > Math.max(need, 1) + 1) continue; if (!vOverlap(levels(a), levels(b))) continue;
      if ((a.attached || b.attached) && (a.group != null && a.group === b.group)) continue; // attached homes in one row
      if (a.court && a.court === b.court) continue; // the wings of one courtyard building
      if (['townhomes', 'duplex'].includes(a.use) && a.use === b.use && boxGap(bx.get(a), bx.get(b)) < 0.6) continue; // a townhome row's units share party walls
      let d = Infinity; for (const s of sh.get(a)) for (const t of sh.get(b)) d = Math.min(d, polyDist(s, t)); least = Math.min(least, d);
      if (d < need - TOL.len) bad.push(id(a) + ' – ' + id(b) + ' ' + d.toFixed(1) + ' ft');
    }
    add({ id: 'separation.buildings', title: 'Space between buildings', status: !rv ? 'unknown' : bad.length ? 'fail' : 'pass', measured: Number.isFinite(least) ? +least.toFixed(2) : null, note: Number.isFinite(least) ? '' : B.length > 1 ? 'No two buildings within ' + (Math.max(need, 1) + 1) + ' ft of each other.' : '', required: need, units: 'ft', tolerance: TOL.len + ' ft', features: bad.slice(0, 30), basis: basisOf(rv), rule: rv?.source || 'No separation rule given' });
  }

  // 7–9. access: an entrance on an allowed street edge; every paved piece reached from it; every building near reached paving
  const paved = els.filter(e => PAVED.includes(e.kind) || e.kind === 'garage');
  const allowed = new Set((brief?.site?.access?.edges || [front, ...streets]).map(mapEdge));
  const rl = roles(ring, front, streets), edgeOf = s => { let best = -1, bd = Infinity; for (const p of s) for (let i = 0; i < n; i++) { const d = segDist(p, ring[i], ring[(i + 1) % n]); if (d < bd) { bd = d; best = i; } }
    for (let i = 0; i < n && bd > 0; i++) for (let k = 0; k < s.length; k++) if (segsCross(s[k], s[(k + 1) % s.length], ring[i], ring[(i + 1) % n])) { bd = 0; best = i; break; } // (a drive that runs across the line, its apron out in the street, meets it)
    return { edge: best, d: bd }; };
  // an emergency access lane (a gated fire lane: IFC D106.3 / D107.2 let the fire official accept one as the second way
  // in) counts toward the fire code's two ways in, never as the entrance traffic uses; it may meet any lot line (an
  // easement across the neighbour's land where it isn't a street)
  const emer = paved.filter(e => e.kind === 'drive' && e.emergency && sh.get(e).some(s => edgeOf(s).d <= 2));
  const entries = paved.filter(e => e.kind === 'drive' && !e.emergency && sh.get(e).some(s => edgeOf(s).d <= 2));
  const legal = entries.filter(e => sh.get(e).some(s => { const q = edgeOf(s); return q.d <= 2 && allowed.has(q.edge); }));
  const illegal = entries.filter(e => !legal.includes(e) && sh.get(e).some(s => { const q = edgeOf(s); return q.d <= 2 && rl[q.edge] !== 'front'; }));
  { // a second way in: IFC Appendix D (D106.1 over 200 apartment units, D107.1 over 30 one- and two-family homes), the two
    // separated by at least half the site's longest diagonal (D104.3 / D106.3). Appendix D applies where the jurisdiction
    // adopts it: an assumption until the rule sheet says so.
    const qq = quantities(layout, brief), apts = qq.byUse.multifamily?.units || 0, homes = ['townhomes', 'duplex', 'sfr'].reduce((t, u) => t + (qq.byUse[u]?.units || 0), 0);
    const need = apts > 200 || homes > 30 ? 2 : 1;
    let diag = 0; for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) diag = Math.max(diag, Math.hypot(ring[i][0] - ring[j][0], ring[i][1] - ring[j][1]));
    const mouths = legal.concat(emer).map(e => { const pts = sh.get(e).flat().filter(p => ptPolyDist(p, ring) <= 3 || !inPoly(p, ring)); return pts.length ? [pts.reduce((t, p) => t + p[0], 0) / pts.length, pts.reduce((t, p) => t + p[1], 0) / pts.length] : null; }).filter(Boolean);
    let apart = 0; for (let i = 0; i < mouths.length; i++) for (let j = i + 1; j < mouths.length; j++) apart = Math.max(apart, Math.hypot(mouths[i][0] - mouths[j][0], mouths[i][1] - mouths[j][1]));
    const two = need === 1 || mouths.length >= 2, far = mouths.length >= 2 && apart >= diag / 2 - TOL.len;
    add({ id: 'access.second', title: 'A second way in where the fire code asks for one', status: need === 1 ? 'n/a' : two ? 'pass' : 'fail', measured: mouths.length, required: need, units: 'entrances',
      basis: 'assumption', rule: 'IFC Appendix D: D106 (over 200 apartments), D107 (over 30 homes), where adopted', note: (need === 2 ? apts + ' apartments and ' + homes + ' homes on the plan.' : '') + (need === 2 && emer.length ? ' One way in is an emergency access lane (gated): the fire official must accept it (IFC D106.3 / D107.2)' + (emer.some(e => sh.get(e).some(s => { const q = edgeOf(s); return q.d <= 2 && !allowed.has(q.edge); })) ? ', and it needs an access easement across the neighbouring land.' : '.') : ''), features: emer.map(id) });
    add({ id: 'access.remote', title: 'The two ways in far enough apart', hard: false, status: need === 1 || mouths.length < 2 ? 'n/a' : far ? 'pass' : 'fail', measured: mouths.length >= 2 ? Math.round(apart) : null, required: Math.round(diag / 2), units: 'ft between entrances',
      basis: 'assumption', rule: 'IFC D104.3 / D106.3: at least half the site’s longest diagonal apart, where adopted (the fire official may accept an emergency-only access instead)' });
  }
  add({ id: 'access.entrance', title: 'A way in from an allowed street edge', status: legal.length && !illegal.length ? 'pass' : 'fail', measured: legal.length, required: 1, units: 'entrances', features: [...legal.map(id), ...illegal.map(e => id(e) + ' (not on an allowed street edge)')], basis: brief?.site?.access?.edges ? 'brief' : 'assumption', rule: brief?.site?.access?.edges ? 'Access only on the edges the brief allows' : 'Access on the front or a side street (no access rights across neighbours)' });
  {
    const adj = new Map(paved.map(e => [e, []]));
    for (let i = 0; i < paved.length; i++) for (let j = i + 1; j < paved.length; j++) {
      const a = paved[i], b = paved[j]; if (!bx.get(a) || !bx.get(b) || boxGap(bx.get(a), bx.get(b)) > TOL.touch) continue;
      let d = Infinity; for (const s of sh.get(a)) for (const t of sh.get(b)) { d = Math.min(d, polyDist(s, t)); if (d <= TOL.touch) break; }
      if (d <= TOL.touch) { adj.get(a).push(b); adj.get(b).push(a); }
    }
    const seen = new Set(legal), q = [...legal]; while (q.length) { const e = q.pop(); for (const o of adj.get(e) || []) if (!seen.has(o)) { seen.add(o); q.push(o); } }
    const lost = paved.filter(e => !seen.has(e));
    add({ id: 'access.connectivity', title: 'All drives and parking connected to the way in', status: !legal.length ? 'fail' : lost.length ? 'fail' : 'pass', measured: lost.length, required: 0, units: 'unreached paved pieces', tolerance: TOL.touch + ' ft', features: lost.map(id).slice(0, 40), rule: 'Paving forms one network from a legal entrance' });
    const rv = ruleOf('buildingToDrive'), need = +rv?.v || 60, far = [];
    const reached = [...seen].filter(e => e.kind === 'drive' || e.kind === 'parking' || e.kind === 'truck' || e.kind === 'field');
    // a building inside another one's court (a clubhouse in a courtyard building) is reached through it
    const hull = pts => { const P = pts.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]), cr = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]), lo = [], up = []; for (const p of P) { while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], p) <= 0) lo.pop(); lo.push(p); } for (const p of P.slice().reverse()) { while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], p) <= 0) up.pop(); up.push(p); } return lo.slice(0, -1).concat(up.slice(0, -1)); };
    const groups = {}; for (const e of els.filter(e => e.kind === 'building' && e.court)) (groups[e.court] = groups[e.court] || []).push(e);
    const courts = Object.entries(groups).map(([g, list]) => ({ g, h: hull(list.flatMap(e => sh.get(e).flat())) }));
    const inCourt = b => courts.find(c => b.court !== c.g && sh.get(b).flat().every(p => inPoly(p, c.h)));
    for (const b of els.filter(e => e.kind === 'building' && !e.future)) {
      if (inCourt(b)) continue; // (its court's building is checked itself)
      let d = Infinity; for (const p of reached) { if (!bx.get(p) || boxGap(bx.get(b), bx.get(p)) > need) continue; for (const s of sh.get(b)) for (const t of sh.get(p)) d = Math.min(d, polyDist(s, t)); if (d <= need) break; }
      if (d > need + TOL.len) far.push(id(b) + (Number.isFinite(d) ? ' ' + Math.round(d) + ' ft' : ' (none near)'));
    }
    // a podium garage's entrance reached by a drive of the network (its spaces count only if a car can get in)
    const garages = els.filter(e => towerOf(e)?.park > 0 && !e.future), shut = [];
    for (const b of garages) { const at = S.garageEntry(b).at; if (!reached.some(p => (p.kind === 'drive' || p.kind === 'parking') && sh.get(p).some(s0 => inPoly(at, s0) || ptPolyDist(at, s0) <= 3))) shut.push(id(b)); }
    add({ id: 'access.garage', title: 'Every podium garage reached by a drive', status: !garages.length ? 'n/a' : shut.length ? 'fail' : 'pass', measured: shut.length, required: 0, units: 'garages with no drive in', tolerance: '3 ft', features: shut, rule: 'The garage entrance on the podium (not the lobby face) meets a drive of the network' });
    add({ id: 'access.buildings', title: 'Every building near connected circulation', status: far.length ? 'fail' : 'pass', measured: far.length, required: 0, units: 'buildings too far', tolerance: need + ' ft', features: far.slice(0, 40), basis: basisOf(rv), rule: rv?.source || 'Planning default 60 ft' });
  }

  { // one-way parking aisles (angled parking): each end meets a two-way drive, so traffic that enters an aisle has a way
    // on and the aisles work as a circulation (a one-way aisle is never a fire lane: access.fire-width and the fire route
    // leave it out); the angled stalls beside an aisle lean the way its traffic runs (a driver turns in forward)
    const isAisle1 = e => e.kind === 'drive' && !e.future && !e.path && !e.poly && +e.w > 0 && +e.d > 0 && TURN.oneWayLane(e) && !/drive-?thru|bypass/i.test((e.name || '') + ' ' + (e.note || ''));
    const ows = els.filter(isAisle1), two = els.filter(e => (e.kind === 'drive' || e.kind === 'truck') && !e.future && !TURN.oneWayLane(e)), bad = [];
    const angRows = els.filter(e => e.kind === 'parking' && !e.future).map(e => ({ e, st: angledStalls(e, sh.get(e)) })).filter(q => q.st?.length);
    for (const a of ows) {
      const r = (+a.rot || 0) * Math.PI / 180, long = +a.w >= +a.d, u = long ? [Math.cos(r), Math.sin(r)] : [-Math.sin(r), Math.cos(r)], v = [-u[1], u[0]], Lh = Math.max(+a.w, +a.d) / 2, Wh = Math.min(+a.w, +a.d) / 2;
      const at = (t, q) => [a.x + u[0] * t + v[0] * q, a.y + u[1] * t + v[1] * q];
      for (const sg of [-1, 1]) { const probe = [at(sg * (Lh - 3), -Wh + 2), at(sg * (Lh + 3), -Wh + 2), at(sg * (Lh + 3), Wh - 2), at(sg * (Lh - 3), Wh - 2)];
        if (!two.some(o => o !== a && sh.get(o).some(q => polyDist(probe, q) <= TOL.touch))) bad.push(id(a) + ' ' + (sg > 0 ? '+' : '-') + 'end meets no two-way drive'); }
      if (a.flow !== 1 && a.flow !== -1) { bad.push(id(a) + ' has no direction marked'); continue; }
      const f = [u[0] * a.flow, u[1] * a.flow], off = p => (p[0] - a.x) * v[0] + (p[1] - a.y) * v[1], along = p => (p[0] - a.x) * u[0] + (p[1] - a.y) * u[1];
      for (const { e, st } of angRows) for (const q of st) { const [p0, , , p1] = q.corners, d0 = Math.abs(off(p0)), d1 = Math.abs(off(p1)), near = d0 < d1 ? p0 : p1, far = d0 < d1 ? p1 : p0;
        if (Math.min(d0, d1) > Wh + 1.5 || Math.abs(along(near)) > Lh + 1) continue; // (a stall along this aisle: its stripe starts at the aisle's edge)
        if ((far[0] - near[0]) * f[0] + (far[1] - near[1]) * f[1] <= 0) { bad.push(id(e) + ' leans against ' + id(a) + '’s traffic'); break; } }
    }
    add({ id: 'access.one-way', title: 'One-way aisles work as a circulation', status: !ows.length ? 'n/a' : bad.length ? 'fail' : 'pass', measured: bad.length, required: 0, units: 'problems', features: bad.slice(0, 30), basis: 'geometry',
      rule: 'Each one-way parking aisle (angled parking) meets a two-way drive at both ends, its direction marked, and the angled stalls beside it lean the way it runs; one-way aisles are not fire lanes', note: ows.length ? ows.length + ' one-way aisle' + (ows.length > 1 ? 's' : '') + ', ' + angRows.length + ' angled row' + (angRows.length === 1 ? '' : 's') + '.' : '' });
  }

  // 10. parking: required (from the brief's rules) and provided (counted from the drawing) reported separately
  const q = quantities(layout, brief);
  {
    const short = q.parking.required - q.parking.provided, est = q.parking.garageEstimated > 0;
    add({ id: 'parking.count', title: 'Parking provided against required', status: q.parking.required == null ? 'unknown' : short > 0 ? 'fail' : est ? 'unknown' : 'pass', measured: q.parking.provided, required: q.parking.required, units: 'spaces', tolerance: '0 spaces',
      basis: q.parking.basis, rule: q.parking.rule, note: (q.parking.tucked ? q.parking.tucked + ' spaces are tuck-under garages, one under each home (counted as stated, never more than fit along a row: 11 ft a garage). ' : '') + (q.parking.podium ? q.parking.podium + ' spaces are on parking podium levels, counted from the podium\'s garage plan (9 × 18 ft stalls, 24 ft aisles, a 12-stall ramp and two stair / elevator cores a level, the lobby on the ground level); a schematic plan, not a structural design. ' : '') + (q.parking.garage ? q.parking.garage + ' spaces are in a parking garage, counted from the same schematic garage plan over its levels (ramp and cores each level). ' : '') + (q.parking.driveways ? q.parking.driveways + ' are driveway aprons in front of front-load duplex garages (tandem; local code may not count them). ' : '') + (est ? q.parking.garageEstimated + ' spaces are a garage estimate (area ÷ 330 sf a space × levels), not a counted layout. ' : '') + 'Accessible spaces needed: ' + q.parking.accessibleNeeded + ' (2010 ADA Standards 208.2); their placement and routes are not checked.' });
    const bad = q.parking.strayStalls;
    add({ id: 'parking.geometry', title: 'Drawn stalls sit on their parking rows', status: bad.length ? 'fail' : q.parking.surface ? 'pass' : 'n/a', measured: q.parking.surface, units: 'surface stalls counted', features: bad.slice(0, 30), rule: 'Each stall inside its row, inside the site and clear of buildings; stall ' + q.parking.stall.w + ' × ' + q.parking.stall.d + ' ft, aisle ' + q.parking.stall.aisle + ' ft', basis: basisOf(ruleOf('stall')) });
  }

  { // dead-end parking aisles: past the last place another drive, a turnaround or the paving under the lot meets an
    // aisle, how far its stalls run on. A driver who finds no space there backs out the whole way; more than
    // DEAD_AISLE ft is a warning (usability; IFC D103.4's 150 ft for a fire road is the yardstick, parking aisles are not
    // taken as fire lanes). Stalls from the drawn marks; an aisle is a straight drive 40 ft wide or less with stalls along it.
    const DEAD_AISLE = 150, net = els.filter(e => (e.kind === 'drive' || e.kind === 'truck' || e.kind === 'field') && !e.future && !/drive-?thru/i.test((e.name || '') + ' ' + (e.note || '')));
    const pts = els.filter(e => e.kind === 'parking' && !e.future && !e.rv).flatMap(e => { try { return S.stallCentres(e); } catch { return []; } });
    const long = []; let aisles = 0;
    for (const a of net) {
      if (a.kind !== 'drive' || a.path || a.poly || isEntrance(a) || !(+a.w > 0 && +a.d > 0)) continue; // (a driveway's street end is a way out)
      const Lh = Math.max(+a.w, +a.d) / 2, Wh = Math.min(+a.w, +a.d) / 2; if (Lh < 30 || Wh > 20) continue;
      const r = (+a.rot || 0) * Math.PI / 180, u = +a.w >= +a.d ? [Math.cos(r), Math.sin(r)] : [-Math.sin(r), Math.cos(r)], v = [-u[1], u[0]];
      const at = (t, q) => [a.x + u[0] * t + v[0] * q, a.y + u[1] * t + v[1] * q], along = p => (p[0] - a.x) * u[0] + (p[1] - a.y) * u[1], off = p => Math.abs((p[0] - a.x) * v[0] + (p[1] - a.y) * v[1]);
      const ts = pts.filter(p => off(p) >= Wh - 1 && off(p) <= Wh + 21 && Math.abs(along(p)) <= Lh + 30).map(along); if (!ts.length) continue; aisles++;
      // where the rest of the network meets it: each piece's stretch along it inside a band down its middle (a piece
      // that only touches it, its stretch where it touches)
      const band = [at(-Lh - 80, -(Wh - 4)), at(Lh + 80, -(Wh - 4)), at(Lh + 80, Wh - 4), at(-Lh - 80, Wh - 4)], self = sh.get(a)[0], joins = [];
      for (const o of net) { if (o === a || !bx.get(o) || boxGap(bx.get(o), bx.get(a)) > TOL.touch) continue;
        for (const q of sh.get(o)) { if (polyDist(q, self) > TOL.touch) continue; let ps = [];
          try { ps = polyclip.intersection([closed(q)], [closed(band)]).flatMap(pg => pg[0]); } catch { ps = []; }
          if (!ps.length) ps = q.filter(p => ptPolyDist(p, self) <= TOL.touch + 0.5);
          if (ps.length) joins.push([Math.min(...ps.map(along)), Math.max(...ps.map(along))]); } }
      if (!joins.length) continue; // (cut off from the network: access.connectivity's to judge)
      const lo = Math.min(...joins.map(j => j[0])), hi = Math.max(...joins.map(j => j[1])), sMin = Math.min(...ts) - 4.5, sMax = Math.max(...ts) + 4.5;
      for (const len of [sMax - hi, lo - sMin]) if (len > DEAD_AISLE + TOL.len) long.push({ a, len: Math.round(len) });
    }
    add({ id: 'parking.dead-end-aisle', title: 'No long dead-end parking aisle', hard: false, status: !aisles ? 'n/a' : long.length ? 'fail' : 'pass', measured: long.length ? Math.max(...long.map(x => x.len)) : 0, required: DEAD_AISLE, units: 'ft of stalls past the last way out', tolerance: TOL.len + ' ft',
      features: long.map(x => id(x.a) + ' ' + x.len + ' ft').slice(0, 30), basis: 'assumption', rule: 'A parking aisle\'s stalls run no more than 150 ft past the last drive, turnaround or open paving joining it (planning practice; IFC D103.4\'s length for a dead end without a turnaround)' });
  }

  // 10b. queues (drive-thru lanes, a car wash's stacking lanes): the cars waiting in them stay off the drive aisles, the
  // parking and the street, and there are as many as the building type asks for (lib/btsite.mjs QUEUE_NEED). Measured
  // along each lane's centre line every 2 ft where cars wait: past where it leaves its drive (half its width and 4 ft, or
  // where the lane says its queue starts) up to its window (or its last 4 ft), no point inside another drive, a parking row
  // or outside the property line.
  {
    const QL = els.filter(e => e.kind === 'drive' && e.note === 'Drive-thru lane' && Array.isArray(e.path) && e.path.length > 1 && !e.future);
    const EP = brief?.program?.engine || layout.program || {}, dt = (EP.extras || []).includes('drivethru'), bt = EP.btype || (dt && ['retail', 'restaurant'].includes(EP.use) ? 'ret-drive-through' : null), need = QUEUE_NEED[bt] || null; // (a drive-thru asked for with no type: the restaurant's rule)
    const wantQ = need && (bt === 'car-wash' || dt);
    if (QL.length || wantQ) {
      const other = els.filter(e => (e.kind === 'drive' && e.note !== 'Drive-thru lane' || e.kind === 'truck' || e.kind === 'parking') && !e.future), blocked = [];
      for (const q of QL) {
        const P = q.path, w = +q.width || 12, len = P.slice(1).reduce((t, p, i) => t + Math.hypot(p[0] - P[i][0], p[1] - P[i][1]), 0), pts = [];
        let at = 0; for (let i = 0; i + 1 < P.length; i++) { const a = P[i], b = P[i + 1], L = Math.hypot(b[0] - a[0], b[1] - a[1]); for (let s = 0; s < L; s += 2) pts.push({ p: [a[0] + (b[0] - a[0]) * s / L, a[1] + (b[1] - a[1]) * s / L], d: at + s }); at += L; }
        const q0 = Math.max(w / 2 + 4, +q.queueFrom || 0), q1 = Math.min(len - 4, +q.windowAt > 0 ? +q.windowAt : len), mid = pts.filter(x => x.d > q0 && x.d < q1); // (where cars wait: from where it leaves the drive, or where its queue starts as drawn, to its window)
        const onDrive = mid.filter(x => other.some(o => (!bx.get(o) || (b => x.p[0] >= b[0] - 1 && x.p[0] <= b[2] + 1 && x.p[1] >= b[1] - 1 && x.p[1] <= b[3] + 1)(bx.get(o))) && sh.get(o).some(r => inPoly(x.p, r)))), off = ring?.length >= 3 ? mid.filter(x => !inPoly(x.p, ring)) : [];
        if (onDrive.length) blocked.push(id(q) + ': ' + onDrive.length * 2 + ' ft of its queue on a drive or parking near ' + onDrive[0].p.map(v => Math.round(v)).join(', '));
        if (off.length) blocked.push(id(q) + ': ' + off.length * 2 + ' ft of its queue outside the property line (in the street)');
      }
      add({ id: 'queues.clear', title: 'Queues clear of the drive aisles, the parking and the street', hard: false, status: !QL.length ? 'n/a' : blocked.length ? 'fail' : 'pass', measured: blocked.length, required: 0, units: 'queue lanes in the way', features: blocked.slice(0, 20), basis: 'geometry',
        rule: 'Each drive-thru or stacking lane, past where it leaves its drive, runs on its own paving: none of its centre line (sampled every 2 ft) inside another drive, a parking row or outside the property line' });
      const wash = QL.filter(e => e.queue === 'carwash'), cars = bt === 'car-wash' ? wash.reduce((t, e) => t + Math.floor(e.path.slice(1).reduce((s, p, i) => s + Math.hypot(p[0] - e.path[i][0], p[1] - e.path[i][1]), 0) / 20 + 1e-6), 0) : QL.length ? Math.min(...QL.map(e => +e.stack || 0)) : 0;
      if (wantQ) add({ id: 'queues.stack', title: 'Queue holds the cars the building type asks for', hard: false, status: !QL.length ? 'fail' : cars >= need.cars ? 'pass' : 'fail', measured: cars, required: need.cars, units: 'cars (' + need.what + ')', basis: 'assumption',
        rule: (bt === 'car-wash' ? 'The car wash’s stacking lanes measured along their centre lines, 20 ft a car' : 'The drive-thru lane’s stacking behind its order point or window as drawn, 20 ft a car') + '; ' + need.cars + ' wanted: ' + need.src, note: !QL.length ? 'No queue lane drawn.' : '' });
    }
  }

  // 11. the program, by what each quantity means
  for (const u of brief?.program?.uses || []) {
    const same = (brief.program.uses || []).filter(x => x.use === u.use).length, zoned = u.zone != null && (q.byZone[u.zone] || same > 1); // a mixed plan: this use's own zone (by the zone its buildings carry); a use with no zone tags and no twin: its use's total
    const g0 = (zoned ? q.byZone[u.zone] : q.byUse[u.use]) || (els.length ? { units: 0, gfa: 0, buildings: 0 } : null); // a use with no building on the plan has none of it (0), not an unknown
    const got = !g0 ? null : u.quantity.unit === 'units' ? g0.units : u.quantity.unit === 'sf' ? g0.gfa : g0.buildings, Q = u.quantity;
    const est = u.quantity.unit === 'units' && g0?.unitsEstimated;
    const ok = got == null ? null : Q.mode === 'exact' ? (Q.unit === 'sf' ? Math.abs(got - Q.value) <= Q.value * 0.01 : got === Q.value) : Q.mode === 'min' ? got >= Q.value : Q.mode === 'max' ? got <= Q.value : Q.mode === 'range' ? got >= Q.min && got <= Q.max : got > 0; // maximize: as many as fit, and none is not an answer
    add({ id: 'program.' + u.id, title: 'Program: ' + (u.name || u.use) + ' (' + (Q.mode === 'maximize' ? 'as many as fit' : Q.mode) + ')', status: ok == null ? 'unknown' : !ok ? 'fail' : est && Q.mode !== 'maximize' ? 'unknown' : 'pass', measured: got ?? null, required: Q.mode === 'range' ? [Q.min, Q.max] : Q.value ?? 'as many as fit', units: Q.unit, tolerance: Q.mode === 'exact' && Q.unit === 'sf' ? '1%' : Q.mode === 'exact' ? '0' : null, basis: 'brief', rule: 'The quantity asked for, as ' + Q.mode,
      note: est ? 'Units are estimated from floor area (no building schedule): a coarse capacity, not a unit count.' : '' });
    // an anchored center: one store of the anchor's floor area (within 5%), and the rest of the use's floor area in other
    // buildings (shops), not one box holding both
    if (u.anchor?.value > 0) {
      const A = u.anchor.value, base = layout.program?.use, bs = els.filter(e => e.kind === 'building' && !e.future && (e.use || base) === u.use).map(e => floorArea(e, u.use)).sort((a, b) => b - a);
      const big = bs[0] || 0, rest = bs.slice(1).reduce((t, v) => t + v, 0), total = big + rest, wantRest = u.quantity.unit === 'sf' && u.quantity.mode !== 'maximize' ? Math.max(0, (u.quantity.mode === 'range' ? u.quantity.min : u.quantity.value) - A) : 0;
      const okA = Math.abs(big - A) <= A * 0.05, okR = wantRest < 1000 || rest >= wantRest * 0.9;
      add({ id: 'program.' + u.id + '.anchor', title: 'Program: anchor store (' + Math.round(A).toLocaleString('en-US') + ' sf) and shops', status: !bs.length ? 'fail' : okA && okR ? 'pass' : 'fail', measured: { anchor: Math.round(big), shops: Math.round(rest), buildings: bs.length }, required: { anchor: A, shops: wantRest }, units: 'sf', tolerance: 'anchor 5%, shops 10%', basis: 'brief',
        rule: 'The largest ' + u.use + ' building is the anchor at the size asked for; the other floor area (' + Math.round(wantRest).toLocaleString('en-US') + ' sf of ' + Math.round(total).toLocaleString('en-US') + ' drawn) is in separate shop buildings' });
    }
    if (u.form === 'ind-cross-dock') crossDockChecks(layout, els, u, add);
  }

  // 12a. apartment buildings the form's reviewed template should size that no template fits (too shallow, too short):
  // their units come from floor area, not the template's schedule (the run marks them tplMiss); said, not counted silently
  { const miss = els.filter(x => x.kind === 'building' && x.tplMiss && !x.future);
    if (miss.length || els.some(x => x.kind === 'building' && x.template)) add({ id: 'program.template', title: 'Apartment buildings drawn to their template', hard: false, status: miss.length ? 'fail' : 'pass', measured: miss.length, required: 0, units: 'buildings no template fits', features: miss.slice(0, 30).map(e => id(e) + ': ' + e.tplMiss), basis: 'assumption', rule: 'The building template of the form asked for (lib/reftemplates.mjs, from the reviewed reference plans): a building no template fits has its units estimated from floor area', note: (deepB => deepB.length ? deepB.length + ' building' + (deepB.length > 1 ? 's' : '') + ' drawn ' + [...new Set(deepB.map(e => /-d(\d+)$/.exec(e.template)[1]))].join(' / ') + ' ft deep as the request asks: an assumption, deeper than any reviewed corridor building (65 ft); each home is larger, the same homes a floor.' : '')(els.filter(x => x.kind === 'building' && /-d\d+$/.test(x.template || '') && !x.future)) }); }
  // 12. buildings: units against floor area and their template
  {
    const bad = [], est = [];
    for (const e of els.filter(x => x.kind === 'building' && ['multifamily'].includes(x.use || layout.program?.use))) {
      const fa = sh.get(e).reduce((s, r) => s + area(r), 0), gsf = fa * (+e.floors || 1), u = e.units;
      if (u == null) { est.push(id(e)); continue; }
      if (u * 400 > gsf) bad.push(id(e) + ': ' + u + ' units in ' + Math.round(gsf) + ' gsf');
      if (e.template && e.tplUnits != null && e.tplUnits !== u) bad.push(id(e) + ': ' + u + ' units but its template schedule gives ' + e.tplUnits);
      if (e.template && e.combined != null && !(+e.combined >= 0 && +e.combined <= (+e.modules || 0) * (+e.floors || 1))) bad.push(id(e) + ': ' + e.combined + ' pairs of homes combined, more than one a floor of each stack'); // (pairs combined into larger homes: at most one a floor of a stack)
      if (e.template && e.tplL && Math.abs(Math.max(e.w, e.d) - e.tplL) > TOL.len) bad.push(id(e) + ': ' + Math.max(e.w, e.d).toFixed(1) + ' ft long, its template schedule was set for ' + e.tplL + ' ft');
    }
    add({ id: 'program.buildings', title: 'Units reconcile with each building', status: bad.length ? 'fail' : est.length ? 'unknown' : 'pass', measured: bad.length, units: 'buildings that don’t reconcile', features: [...bad, ...est.map(x => x + ' (units estimated from floor area)')].slice(0, 40), rule: 'At least 400 gsf a unit; a templated building keeps its schedule and module length', basis: 'geometry', hard: !est.length || bad.length > 0 });
  }

  { // attached homes in rows no longer than a row holds: a townhome building (and a rental court's townhome row) of at most
    // the brief's row length, else 6 homes (the engine's own row; a planning default: fire separation and the building
    // code's townhouse limits set the real one). A row of 11 is an apartment bar, not townhomes.
    const cap = +(R.townhomeRowMax?.v) || 6, court = layout.program?.product === 'court6' ? 6 : layout.program?.product === 'court' ? 2 : null;
    const rows = els.filter(e => e.kind === 'building' && !e.future && ((e.use || layout.program?.use) === 'townhomes' || court && (e.use || layout.program?.use) === 'multifamily'));
    const over = rows.filter(e => (+e.units || 1) > (court && (e.use || layout.program?.use) === 'multifamily' ? court : cap));
    add({ id: 'program.rowlength', title: 'Attached homes in rows no longer than a row holds', status: !rows.length ? 'n/a' : over.length ? 'fail' : 'pass', measured: rows.length ? Math.max(...rows.map(e => +e.units || 1)) : null, required: court || cap, units: 'homes in the longest row',
      features: over.map(e => id(e) + ': ' + e.units + ' homes'), basis: R.townhomeRowMax ? 'brief' : 'assumption', rule: R.townhomeRowMax?.source || 'Planning default: rows of at most ' + (court || cap) + ' attached homes (fire separation and the local townhouse rules set the real limit)' });
  }

  // 13. locks: a locked piece unchanged
  if (brief?.locked && Object.keys(brief.locked).length) {
    const by = new Map(els.map(e => [e.id, e])), moved = [];
    for (const [lid, was] of Object.entries(brief.locked)) { const e = by.get(lid); if (!e) { moved.push(lid + ' (missing)'); continue; } const s = sh.get(e)[0] || [], w = was.shape || []; if (s.length !== w.length || s.some((p, i) => Math.hypot(p[0] - w[i][0], p[1] - w[i][1]) > TOL.lock)) moved.push(lid + ' (moved or reshaped)'); }
    add({ id: 'locks', title: 'Locked pieces unchanged', status: moved.length ? 'fail' : 'pass', measured: moved.length, units: 'locked pieces changed', tolerance: TOL.lock + ' ft', features: moved, basis: 'brief', rule: 'What the brief locks stays as it was' });
  } else add({ id: 'locks', title: 'Locked pieces unchanged', status: 'n/a', basis: 'brief', rule: 'Nothing locked' });

  // 14. what this validator does not check (always reported, never passed)
  const pond = els.filter(e => e.kind === 'pond');
  { const pondSf = Math.round(pond.reduce((s, e) => s + sh.get(e).reduce((t, r) => t + area(r), 0), 0)); let need, st0 = null; try { const st = S.stormOf({ ...layout, ring: layout.ring || ring, elements: els }); st0 = st; need = st?.area ? Math.round(st.area) : null; } catch { need = null; }
    const short = need && pondSf < need * 0.97;
    // with the design storm known, the pond is judged against a planning-level hydrologic estimate (lib/hydrology.mjs:
    // TR-55 chapter 6) and passes or fails on it, never hard (the civil engineer sizes the pond); without it, unknown
    const hy = st0?.hydro, off = brief?.site?.stormwater === 'offsite' || st0?.mode === 'none' && !pondSf, vault = brief?.site?.stormwater === 'underground' || st0?.mode === 'underground';
    const hyNote = hy ? 'Estimated by ' + hy.method + ': the ' + hy.rain.rp + '-year 24-hour storm, ' + hy.rain.p + ' in (' + hy.rain.source + '); ' + Math.round(hy.imp * 100) + '% impervious (' + (hy.impFrom === 'drawn' ? 'as drawn' : 'typical for the use') + '), soil group ' + hy.hsg + ' (assumed), CN ' + hy.cnPost + ' after / ' + hy.cnPre + ' before, C ' + hy.cPost + ' / ' + hy.cPre + ', Vs/Vr ' + hy.ratio + ' at qo/qi ' + hy.qoqi + ': ' + hy.volume.toFixed(2) + ' ac-ft' + (hy.floor ? '; the floor ' + hy.floor.rate + ' ac-ft an acre (' + hy.floor.source + ') = ' + hy.floor.volume.toFixed(2) + ' ac-ft' + (hy.governs === 'floor' ? ' governs' : '') : '') + '. ' : '';
    const hStatus = !hy ? 'unknown' : off || vault ? 'n/a' : !need ? 'pass' : pondSf >= need * 0.97 ? 'pass' : 'fail';
    add({ id: 'eng.detention', title: 'Detention / drainage', status: hStatus, hard: false, measured: pondSf, required: need, units: 'sf of pond', basis: 'assumption', rule: hy ? 'Planning-level estimate, not a drainage design: ' + hy.method + ', with a local minimum where one is known' : 'Concept reserve sized by a rule of thumb (an acre-feet rate and depth); not a drainage design',
      note: (brief?.site?.stormwater === 'offsite' || st0?.mode === 'none' && !pondSf ? 'Detention handled off site (a regional facility), as stated: an assumption, confirm with the civil engineer and the drainage district. ' : brief?.site?.stormwater === 'underground' || st0?.mode === 'underground' ? 'Detention in underground vaults (about ' + (st0?.volume ? st0.volume.toFixed(2) + ' ac-ft' : 'the site’s volume') + ', no pond drawn): an assumption, sized by the civil engineer. ' : '') + (short ? 'The ponds hold about ' + Math.round(pondSf / need * 100) + '% of the ' + (hy ? 'estimated' : 'rule-of-thumb') + ' area: the rest needs underground storage, a deeper pond or a regional facility. ' : '') + hyNote + 'Needs topography, outfall, soils and the jurisdiction’s drainage criteria' + (hy ? ' to confirm.' : '.') }); }
  { // a walking trail through a building or along a parking row (crossing a drive is a crosswalk; along one is not)
    const trails = els.filter(e => e.kind === 'trail' && e.path?.length >= 2), hits = [];
    for (const t of trails) { const w = (+t.width || 6) / 2, segs = []; for (let i = 1; i < t.path.length; i++) { const a = t.path[i - 1], b = t.path[i], L = Math.hypot(b[0] - a[0], b[1] - a[1]); if (L < 0.01) continue; const nx = -(b[1] - a[1]) / L * w, ny = (b[0] - a[0]) / L * w; segs.push([[a[0] + nx, a[1] + ny], [a[0] - nx, a[1] - ny], [b[0] - nx, b[1] - ny], [b[0] + nx, b[1] + ny]]); }
      for (const o of els.filter(e => e.kind === 'building' || e.kind === 'parking' || e.kind === 'pool')) { let A = 0; for (const sg of segs) for (const r of sh.get(o)) A += interArea(sg, r) || 0; if (A > 20) hits.push((t.id || 'trail') + ' × ' + id(o) + ' (' + Math.round(A) + ' sf)'); }
      for (const o of els.filter(e => e.kind === 'drive' && !isEntrance(e))) { let A = 0; for (const sg of segs) for (const r of sh.get(o)) A += interArea(sg, r) || 0; if (A > 40 * w * 2) hits.push((t.id || 'trail') + ' along ' + id(o) + ' (' + Math.round(A) + ' sf)'); } }
    add({ id: 'site.trail', title: 'Walking trail clear of buildings, parking and drives', status: !trails.length ? 'n/a' : hits.length ? 'fail' : 'pass', hard: false, measured: hits.length, units: 'conflicts', features: hits.slice(0, 20), basis: 'geometry', rule: 'A trail may cross a drive (a crosswalk) but not run along it or through a building or parking row' }); }
  // turning movements and fire lanes (lib/turning.mjs): the declared design vehicles' turning envelopes swept through
  // every turn on the paving as drawn; a planning-level check, not a swept-path analysis by an engineer
  {
    // garage ramps, schematic (lib/siteplan.mjs garagePlan rampSpec): the ramp between parking levels long enough for the
    // floor-to-floor rise at its slope
    const ramped = els.filter(e => !e.future && ((towerOf(e)?.park || 0) >= 2 || e.kind === 'garage' && e.grid && (+e.levels || 4) >= 2)), short = [], notes = [];
    for (const g of ramped) { const r = S.garagePlan(g).rampSpec; if (!r) { short.push(id(g) + ': no ramp'); continue; } notes.push(id(g) + ': ' + r.note); if (!r.fits) short.push(id(g) + ' ' + Math.round(r.run) + ' of ' + Math.round(r.need) + ' ft'); }
    add({ id: 'eng.garage-ramp', title: 'Garage ramps long enough for the rise', hard: false, status: !ramped.length ? 'n/a' : short.length ? 'fail' : 'pass', measured: short.length, required: 0, units: 'ramps too short', features: short, basis: 'assumption',
      rule: 'Schematic: a speed ramp at up to 16% with 12 ft transitions at 8%, or a parking ramp at 6.67%, for an ' + S.GARAGE_H.ground.f2f + ' ft floor-to-floor rise; ' + S.GARAGE_H.source + '. Structure, ventilation and drainage are not designed.', note: notes.slice(0, 6).join(' · ') });
    // open or enclosed garage (IBC 406.5.2), from the walls that face the open air: enclosed means mechanical ventilation
    // and sprinklers, a cost and an engineering item, not a layout failure
    const gars = S.garagesOf(els), gv = gars.map(g => ({ g, o: S.garageOpenness(g, els) })), shut = gv.filter(x => !x.o.open);
    add({ id: 'eng.garage-vent', title: 'Garage open to the air, or ventilated', hard: false, status: !gars.length ? 'n/a' : shut.length ? 'fail' : 'pass', measured: gv.length ? Math.round(Math.min(...gv.map(x => x.o.area)) * 100) : null, required: 20, units: '% of the wall area open (worst tier)', features: gv.map(x => id(x.g) + ': ' + x.o.note), basis: 'assumption',
      rule: S.OPEN_GARAGE.rule + '. Schematic: openings between a 42 in spandrel and an 18 in beam where no building stands within 3 ft; a garage under homes is typically Type I-A construction with a 3-hour horizontal separation (IBC 510.2).',
      note: shut.length ? shut.length + ' enclosed garage' + (shut.length > 1 ? 's' : '') + ': plan mechanical ventilation (IMC 404) and sprinklers (IBC 903.2.10).' : gars.length ? 'Open parking garage' + (gars.length > 1 ? 's' : '') + ': natural ventilation.' : '' });
    const dvr = ruleOf('designVehicles'), DV = dvr?.v || {}, VEH = { ...TURN.VEHICLES, ...(DV.defs || {}) }, vOf = k => VEH[DV[k] || TURN.DEFAULT_USE[k]] || null, basis = dvr ? basisOf(dvr) : 'assumption';
    const D = els.filter(e => (e.kind === 'drive' || e.kind === 'truck') && !e.future), pv = TURN.pavingOf(els).concat(TURN.streetPaving(ring, [front, ...streets])), sites = TURN.turnSites(D, e => e), route = TURN.fireRoute(D, els, e => e), onRoute = new Set(route);
    const fails = (veh, list) => list.filter(t => !TURN.turnFits(t, veh, pv).ok).map(t => t.pieces.map(id).join(' × ') + ' at ' + t.where.map(v => Math.round(v)).join(', '));
    const vn = v => v.label + ' (' + v.Ri + ' ft inside / ' + v.Ro + ' ft outside)';
    // the fire code's clear width on every two-way drive (IFC D103.1 / 503.2.1: 20 ft)
    const fire = vOf('fire'), fw = fire?.clear || 20, narrow = D.filter(e => e.kind === 'drive' && !TURN.oneWayLane(e) && (TURN.clearWidth(e) ?? Infinity) < fw - TOL.len);
    add({ id: 'access.fire-width', title: 'Drives at least as wide as the fire code asks', status: !D.length ? 'n/a' : narrow.length ? 'fail' : 'pass', measured: narrow.length ? Math.min(...narrow.map(TURN.clearWidth)) : D.length ? Math.min(...D.filter(e => e.kind === 'drive' && !TURN.oneWayLane(e)).map(e => TURN.clearWidth(e) ?? Infinity)) : null, required: fw, units: 'ft clear', tolerance: TOL.len + ' ft', features: narrow.map(e => id(e) + ' ' + TURN.clearWidth(e) + ' ft').slice(0, 30), basis, rule: 'IFC D103.1 / 503.2.1: fire apparatus access roads 20 ft clear (a one-way drive-thru lane is not one)' });
    // dead ends on the fire route longer than 150 ft need a turnaround (IFC 503.2.5, D103.4)
    const touch = (a, b) => { if (!bx.get(a) || !bx.get(b) || boxGap(bx.get(a), bx.get(b)) > TOL.touch) return false; for (const s of sh.get(a)) for (const t of sh.get(b)) if (polyDist(s, t) <= TOL.touch) return true; return false; };
    const de = TURN.deadEnds(D, touch, id, isEntrance, e => onRoute.has(e));
    add({ id: 'access.dead-end', title: 'No long dead end without a turnaround', status: !route.length ? 'n/a' : de.length ? 'fail' : 'pass', measured: de.length ? Math.max(...de.map(x => x.length)) : 0, required: TURN.DEAD_END, units: 'ft of dead end', features: de.map(x => x.id + ' ' + x.length + ' ft'), basis, rule: 'IFC 503.2.5 / D103.4: a dead-end fire apparatus access road over 150 ft needs a turnaround (a cul-de-sac, hammerhead or loop); parking aisles are not taken as fire lanes' });
    // fire apparatus round the fire route's turns; not needed where every building is within 150 ft of a street
    const streetEdges = ring.map((a, i) => i === front || streets.includes(i) ? [a, ring[(i + 1) % n]] : null).filter(Boolean), Bs = els.filter(e => e.kind === 'building' && !e.future);
    const nearStreet = Bs.length && Bs.every(b => sh.get(b).flat().every(p => streetEdges.some(([a, c]) => segDist(p, a, c) <= 150)));
    const fs = sites.filter(t => t.pieces.every(p => onRoute.has(p))), ff = fire && !nearStreet ? fails(fire, fs) : [];
    add({ id: 'eng.turning.fire', title: 'Fire apparatus turns on the fire route', hard: false, status: !fire ? 'unknown' : nearStreet ? 'n/a' : !fs.length ? 'n/a' : ff.length ? 'fail' : 'pass', measured: fire && !nearStreet ? ff.length : null, required: 0, units: 'turns too tight', features: ff.slice(0, 30), basis,
      rule: (fire ? vn(fire) + '. ' + fire.source : 'No fire apparatus declared') + '. Each turn passes when the vehicle\'s band between its two radii, swept through the turn about some centre, stays on the paving as drawn (within ' + TURN.TOL + ' ft).',
      note: nearStreet ? 'Every building is within 150 ft of a street (straight-line): the fire apparatus works from the street (IFC 503.1.1, where the fire official accepts it).' : fs.length + ' turns on the fire route (drives that are not parking aisles or one-way lanes).' });
    const car = vOf('car'), cf = car ? fails(car, sites) : [];
    add({ id: 'eng.turning.car', title: 'Cars make every turn', hard: false, status: !car ? 'unknown' : !sites.length ? 'n/a' : cf.length ? 'fail' : 'pass', measured: car ? cf.length : null, required: 0, units: 'turns too tight', features: cf.slice(0, 30), basis, rule: car ? vn(car) + '. ' + car.source : 'No passenger car declared' });
    const svc = vOf('service'), ss = sites.filter(t => t.pieces.some(p => /service|loading/i.test((p.name || '') + ' ' + (p.note || '')))), sf = svc ? fails(svc, ss) : [];
    add({ id: 'eng.turning.service', title: 'Service trucks make the service drive\'s turns', hard: false, status: !svc ? 'unknown' : !ss.length ? 'n/a' : sf.length ? 'fail' : 'pass', measured: ss.length ? sf.length : null, required: 0, units: 'turns too tight', features: sf.slice(0, 30), basis, rule: svc ? vn(svc) + '. ' + svc.source : 'No service vehicle declared' });
    // (the truck route: the truck court and the drives that run into it)
    const courts = D.filter(p => p.kind === 'truck' || /truck court/i.test((p.name || '') + ' ' + (p.note || ''))), toCourt = new Set(courts.concat(D.filter(p => !courts.includes(p) && courts.some(c => touch(p, c)))));
    const trk = vOf('truck'), ts = sites.filter(t => t.pieces.some(p => toCourt.has(p))), tf = trk ? fails(trk, ts) : [];
    add({ id: 'eng.turning.truck', title: 'Semitrailers make the truck court\'s turns', hard: false, status: !trk ? 'unknown' : !ts.length ? 'n/a' : tf.length ? 'fail' : 'pass', measured: ts.length ? tf.length : null, required: 0, units: 'turns too tight', features: tf.slice(0, 30), basis, rule: trk ? vn(trk) + '. ' + trk.source : 'No truck declared' });
  }
  add({ id: 'eng.fire-route', title: 'Fire apparatus route distance', status: 'unknown', hard: false, basis: 'assumption', rule: (ruleOf('fireAccess')?.source) || 'IFC 503.1.1', note: 'Distances along the route are not measured; straight-line distance would not prove compliance.' });
  add({ id: 'eng.grading-utilities', title: 'Grading, utilities and capacity', status: 'unknown', hard: false, basis: 'none', rule: 'Not modelled' });
  return finish(C, layout, brief, q);
}

function finish(C, layout, brief, q = null) {
  const hard = C.filter(c => c.hard), fails = hard.filter(c => c.status === 'fail'), unknown = hard.filter(c => c.status === 'unknown');
  const status = fails.length ? 'fail' : unknown.length ? 'incomplete' : 'pass';
  const assumptions = C.filter(c => c.basis === 'assumption' && c.status === 'pass').map(c => c.id);
  return { version: VALIDATOR_VERSION, status, feasible: !fails.length, counts: { pass: C.filter(c => c.status === 'pass').length, fail: C.filter(c => c.status === 'fail').length, unknown: C.filter(c => c.status === 'unknown').length, na: C.filter(c => c.status === 'n/a').length },
    failed: fails.map(c => c.id), unresolved: unknown.map(c => c.id), restsOnAssumptions: assumptions, checks: C, quantities: q };
}

// ---------- quantities, measured from the drawing ----------
function floorArea(e, u, s = shapesOf(e), fa = s.reduce((t, r) => t + area(r), 0)) {
  const drawn = fa * (+e.floors || 1), prec = s.reduce((t, r) => t + perim(r), 0) * 0.005 * (+e.floors || 1) + 0.5;
  return e.gfa != null && (!fa || Math.abs(+e.gfa - drawn) <= prec) ? +e.gfa : (e.sf != null && ['sfr', 'townhomes', 'duplex'].includes(u) ? +e.sf : drawn);
}
// A cross-dock (form ind-cross-dock), measured from the drawing: the largest building of the use has truck court on
// both of its long sides (truck pieces running out from each dock wall, contiguous, at least XD.court ft deep: the
// apron plus the trailer stalls), the trailer stalls drawn along the courts are counted against the dock doors, and no
// truck piece or truck drive touches the car parking (the trucks never cross the cars).
const XD = { court: 130, trailersPerDoor: 0.5, touch: 0.5 };
function crossDockChecks(layout, els, u, add) {
  const base = layout.program?.use, B = els.filter(e => e.kind === 'building' && !e.future && (e.use || base) === u.use && !e.poly).sort((a, b) => b.w * b.d - a.w * a.d)[0];
  const T = els.filter(e => e.kind === 'truck' && !e.poly), cars = els.filter(e => e.kind === 'parking'), truckWays = els.filter(e => e.kind === 'drive' && e.trucks).concat(T);
  if (!B) { add({ id: 'program.' + u.id + '.crossdock', title: 'Cross-dock: truck courts on both long sides', status: 'fail', measured: 0, required: 2, units: 'courts', basis: 'brief', rule: 'A cross-dock has dock doors and a truck court on both long sides' }); return; }
  const ax = B.d >= B.w ? 0 : 1, half = (ax === 0 ? B.w : B.d) / 2, len = ax === 0 ? B.d : B.w; // (the long faces: across local x when the building runs along local y)
  const depthOn = sgn => { // truck pieces out from the face at sgn * half, contiguous: how far they reach
    const iv = T.map(t => S.shapeOf(t).map(p => S.toLocal(B, p))).map(q => { const a = q.map(p => p[ax] * sgn), b = q.map(p => p[1 - ax]); return [Math.min(...a), Math.max(...a), Math.min(...b), Math.max(...b)]; })
      .filter(([, , b0, b1]) => Math.min(b1, len / 2) - Math.max(b0, -len / 2) >= len * 0.5).sort((p, q) => p[0] - q[0]);
    let reach = half; for (const [a0, a1] of iv) { if (a0 > reach + 2) break; reach = Math.max(reach, a1); } return reach - half; };
  const dW = depthOn(-1), dE = depthOn(1), ok = dW >= XD.court - 1 && dE >= XD.court - 1;
  add({ id: 'program.' + u.id + '.crossdock', title: 'Cross-dock: a truck court on both long sides', status: ok ? 'pass' : 'fail', measured: [Math.round(dW), Math.round(dE)], required: XD.court, units: 'ft of court each side', basis: 'assumption',
    rule: 'A cross-dock loads through both long walls: a truck court (maneuvering apron plus trailer stalls) at least ' + XD.court + ' ft deep along each, a planning default for a 53 ft trailer' });
  const doors = (B.docks?.perFace || 0) * (B.docks?.faces?.length || 0), trailers = T.reduce((t, e) => t + Math.min(+e.trailers || 0, Math.floor(Math.max(e.w, e.d) / (+e.trailerW || 12))), 0);
  add({ id: 'program.' + u.id + '.trailers', title: 'Cross-dock: trailer stalls', hard: false, status: !doors ? 'unknown' : trailers >= doors * XD.trailersPerDoor ? 'pass' : 'fail', measured: trailers, required: Math.ceil(doors * XD.trailersPerDoor), units: 'trailer stalls', basis: 'assumption',
    rule: 'Trailer stalls along the courts, counted where they are drawn (at most one a ' + 12 + ' ft of court); about one for every two dock doors (' + doors + ' doors), a planning default' });
  const hit = truckWays.filter(t => cars.some(c => S.gapBetween(S.shapeOf(t), S.shapeOf(c)) <= XD.touch));
  add({ id: 'program.' + u.id + '.trucks', title: 'Cross-dock: trucks kept off the car parking', status: hit.length ? 'fail' : 'pass', measured: hit.length, required: 0, units: 'truck pieces touching car parking', features: hit.map(e => e.id).filter(Boolean).slice(0, 20), basis: 'assumption',
    rule: 'No truck court, trailer stall or truck drive touches a car parking row: the trucks reach the docks on their own drives' });
}
// units: from each building's own count (a schedule) where it has one, else estimated from floor area and flagged
export function quantities(layout, brief = null) {
  const els = (layout.elements || []).filter(e => e && e.kind && shapesOf(e).every(finite)), P = layout.program || {}, base = P.use || 'other', R = brief?.rules?.values || {};
  const byUse = {}, byZone = {}, U = u => (byUse[u] = byUse[u] || { buildings: 0, footprint: 0, gfa: 0, units: 0, unitsEstimated: false }), Z = k => (byZone[k] = byZone[k] || { buildings: 0, footprint: 0, gfa: 0, units: 0, unitsEstimated: false });
  const ring = layout.ring || brief?.site?.ring || [], keysBy = {};
  for (const e of els.filter(x => x.kind === 'building' && !x.future)) {
    const u = e.use || base, s = shapesOf(e), fa = s.reduce((t, r) => t + area(r), 0), gz = e.zone != null ? Z(e.zone) : null, g = U(u); g.buildings++; g.footprint += fa;
    // a floor area the piece states (the run's, drawn at full precision before its sides were stored at 0.01 ft) is taken
    // only where the stored outline agrees with it to that precision (half a hundredth of a foot round the perimeter, each
    // floor); else, or when the piece was changed after, the outline's own area
    const tw = towerOf(e), gr = S.groundOf(e), gfa0 = tw && e.gfa == null ? fa * (tw.podium - tw.park) + tw.plate * tw.up : floorArea(e, u, s, fa); /* a tower on a podium: the podium floors that are not parking, and the tower plate above */
    // vertical mixed use: the ground floor's shops are their own use's floor area (and parking), the building's use the floors above
    const grA = gr ? fa * gr.floors : 0, gfa = gfa0 - grA; g.gfa += gfa;
    if (gr) { const r = U(gr.use); r.buildings++; r.gfa += grA; r.stacked = (r.stacked || 0) + 1; }
    let nU = 0, est = false; if (['multifamily', 'townhomes', 'duplex', 'sfr'].includes(u)) { if (e.units != null) nU = +e.units; else if (u === 'multifamily') { nU = Math.floor(gfa * (P.eff || 0.85) / (P.unitSf || 900)); est = true; } else nU = 1; }
    { const k = keysBy[u] = keysBy[u] || { keys: 0, rest: 0 }; if (+e.keys > 0) k.keys += +e.keys; else k.rest += gfa; } // (keys a typed hotel states: its parking by the key where the rule is a key's)
    g.units += nU; g.unitsEstimated = g.unitsEstimated || est; if (gz) { gz.buildings++; gz.footprint += fa; gz.gfa += gfa; gz.units += nU; gz.unitsEstimated = gz.unitsEstimated || est; gz.use = u; }
  }
  for (const e of els.filter(x => x.kind === 'garage' && x.standalone && !x.future)) { const fa = shapesOf(e).reduce((t, r) => t + area(r), 0), g = U(e.use || base); g.buildings++; g.footprint += fa; g.gfa += fa * (+e.levels || 1); } // a stand-alone parking garage that is the program (lib/btypes.mjs): its levels are its floor area; its spaces are counted below as a garage's
  for (const g of Object.values(byUse)) { g.footprint = Math.round(g.footprint); g.gfa = Math.round(g.gfa); }
  // stalls drawn: each one inside its row, inside the site and not under a building
  const stall = { ...{ w: 9, d: 18, aisle: 24 }, ...(R.stall?.v || {}) }, B = els.filter(e => e.kind === 'building' && !e.future).map(e => shapesOf(e)).flat(), stray = [];
  let surface = 0, square3 = false, angledRows = 0;
  for (const e of els.filter(x => x.kind === 'parking' && !x.rv && !x.vac)) {
    const rows = shapesOf(e), ang = angledStalls(e, rows);
    if (ang) { // angled stripes: the stalls measured from them (angledStalls), each inside its row and the site, clear of buildings
      angledRows++;
      for (const q of ang) { const c = q.c, okRow = q.corners.every(p => rows.some(r => inPoly(p, r) || ptPolyDist(p, r) < 0.5)), okSite = !ring.length || inPoly(c, ring), clear = !B.some(b => inPoly(c, b)); if (okRow && okSite && clear) surface++; else stray.push((e.id || 'parking') + ' @' + c.map(v => Math.round(v)).join(',')); }
      continue;
    }
    let cs; try { cs = S.stallCentres(e); } catch { cs = []; }
    let here = 0;
    for (const c of cs) { const okRow = rows.some(r => inPoly(c, r) || ptPolyDist(c, r) < 0.5), okSite = !ring.length || inPoly(c, ring), clear = !B.some(b => inPoly(c, b)); if (okRow && okSite && clear) { surface++; here++; } else stray.push((e.id || 'parking') + ' @' + c.map(v => Math.round(v)).join(',')); }
    if (here >= 3 && !e.parallel) square3 = true;
  }
  // a tower's parking podium: counted on a stall grid over each parking level (podiumGrid), not drawn stall by stall
  const podium = els.filter(e => e.kind === 'building' && !e.future).reduce((s, e) => { const t = towerOf(e); return s + (t && t.park ? podiumGrid(e, t.park) : 0); }, 0);
  // a garage drawn to a stall grid (a wrap's): counted on the same grid as a podium, each of its levels
  const garage = els.filter(e => e.kind === 'garage' && e.grid && !e.future).reduce((s, e) => s + S.garageStalls(e), 0);
  const garageEstimated = els.filter(e => e.kind === 'garage' && !e.grid).reduce((s, e) => s + Math.floor(shapesOf(e).reduce((t, r) => t + area(r), 0) * (+e.levels || 4) / 330), 0);
  const homes = els.filter(e => e.kind === 'building' && ['townhomes', 'duplex', 'sfr'].includes(e.use || base) && !e.future);
  // tuck-under garages: the 1-car garages a row states (e.tuck), never more than fit along its long face (11 ft wide, 22 ft
  // deep each: E053's tuck-in garage), none in a building too shallow for one
  const tucked = els.filter(e => e.kind === 'building' && +e.tuck > 0 && !e.future).reduce((s, e) => s + (Math.min(+e.w, +e.d) >= 22 ? Math.min(+e.tuck, Math.floor((Math.max(+e.w, +e.d) + 0.5) / 11)) : 0), 0);
  const privateGarages = homes.reduce((s, e) => s + (e.tiny || e.padSpaces != null ? (+e.padSpaces || 1) : (+e.units || 1) * (e.garagePer ?? ({ townhomes: 2, duplex: 1, sfr: 2 }[e.use || base] || 0))), 0); // (a building may say its garage spaces a home: a front-load townhome's one-car garage)
  const driveways = homes.filter(e => ['duplex', 'townhomes'].includes(e.use || base) && /front-load/i.test(e.note || '')).reduce((s, e) => s + (+e.units || 1), 0); // a front-load duplex's driveway apron: one tandem space a home (local code may not count it)
  // required: the brief's ratios, else the engine's use defaults (stated as assumptions)
  const hk = S.HOME_KINDS[P.homeKind || (P.zones || []).find(z => z?.homeKind)?.homeKind]; // (a home community: its kind's parking, a tiny home 1, a cottage 1.5, a manufactured home 2)
  const BU = R.parkingByUse?.v && typeof R.parkingByUse.v === 'object' ? R.parkingByUse.v : {}; // (a mixed plan governed use by use, lib/layoutrun.mjs governingParking: each use at its own rule)
  const perUnitOf = u => BU[u]?.perUnit ?? R.parkingPerUnit?.v ?? (u === 'sfr' && hk ? hk.perUnit : ({ multifamily: 1.6, townhomes: 2.25, duplex: 2, sfr: 2 }[u]));
  const share = u => (brief?.program?.uses || []).find(x => x.use === u && x.officeShare != null)?.officeShare;
  const per1kOf = u => BU[u]?.per1000 ?? R.parkingPer1000?.v ?? (share(u) != null ? +(share(u) * 3.5 + (1 - share(u)) * 0.6).toFixed(3) : null) ?? ({ retail: 4, restaurant: 10, office: 3.5, medical: 5, hotel: 1.82, church: 10, industrial: 0.6, storage: 0.1, fuel: 4, foodtrucks: 8, amenity: 0, other: 3 }[u]);
  let required = 0, known = true;
  for (const [u, g] of Object.entries(byUse)) { const pu = perUnitOf(u), pk = per1kOf(u); if (['multifamily', 'townhomes', 'duplex', 'sfr'].includes(u)) { if (pu == null) known = false; else required += g.units * pu; } else if (BU[u]?.perKey != null) required += (keysBy[u]?.keys > 0 ? keysBy[u].keys + keysBy[u].rest / (+BU[u].sfPerKey || 550) : g.gfa / (+BU[u].sfPerKey || 550)) * BU[u].perKey; /* a hotel by its keys (the typed buildings' own count, else its floor area at the type's sf a key) */ else if (pk == null) known = false; else required += g.gfa / 1000 * pk; }
  required = known ? Math.ceil(required - 0.01) : null;
  const raw = surface, accessibleNeeded = raw <= 0 ? 0 : raw <= 25 ? 1 : raw <= 50 ? 2 : raw <= 75 ? 3 : raw <= 100 ? 4 : raw <= 150 ? 5 : raw <= 200 ? 6 : raw <= 300 ? 7 : raw <= 400 ? 8 : raw <= 500 ? 9 : raw <= 1000 ? Math.ceil(raw * 0.02) : 20 + Math.ceil((raw - 1000) / 100);
  const ruled = R.parkingPerUnit?.v != null || R.parkingPer1000?.v != null || Object.keys(BU).length > 0, verified = R.parkingPerUnit?.cls === 'verified' || R.parkingPer1000?.cls === 'verified' || Object.keys(BU).length > 0 && R.parkingByUse?.cls === 'verified';
  // accessible stalls take their striped access aisle out of the row: each pair of them shares an aisle a stall wide
  // (the app's own count does the same, lib/siteplan.mjs metrics)
  // (where every row is angled, a pair and its aisle, square to the aisle, take four angled stalls: twice the cost)
  const accessAisles = Math.ceil(accessibleNeeded / 2) * (angledRows && !square3 ? 2 : 1);
  const parking = { required, provided: surface - accessAisles + podium + garage + garageEstimated + privateGarages + tucked + driveways, surface, accessAisles, podium, garage, tucked, garageEstimated, privateGarages, driveways, accessibleNeeded, stall, strayStalls: stray,
    basis: verified ? 'verified' : 'assumption', rule: ruled ? (Object.keys(BU).length ? R.parkingByUse.source : R.parkingPerUnit?.source || R.parkingPer1000?.source) : 'Engine use defaults (1.6 a unit for apartments, 4 per 1,000 sf for retail, …): planning assumptions, not code' };
  const site = ring.length >= 3 ? area(ring) : 0, tot = Object.values(byUse).reduce((t, g) => ({ units: t.units + g.units, gfa: t.gfa + g.gfa, footprint: t.footprint + g.footprint, buildings: t.buildings + g.buildings }), { units: 0, gfa: 0, footprint: 0, buildings: 0 });
  const pavedSf = els.filter(e => PAVED.includes(e.kind)).reduce((s, e) => s + shapesOf(e).reduce((t, r) => t + area(r), 0), 0);
  for (const g of Object.values(byZone)) { g.footprint = Math.round(g.footprint); g.gfa = Math.round(g.gfa); }
  return { siteSf: Math.round(site), acres: +(site / 43560).toFixed(3), byUse, byZone, totals: tot, unitsEstimated: Object.values(byUse).some(g => g.unitsEstimated), parking, pavedSfGross: Math.round(pavedSf), duAc: site ? +(tot.units / (site / 43560)).toFixed(2) : 0, far: site ? +(tot.gfa / site).toFixed(3) : 0 };
}
